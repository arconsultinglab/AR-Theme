<header class="page-header">
	<div class="small-container">
		<h1>
			<?php the_title(); ?>
		</h1>
	</div>
</header>

<section>
	<article>
		<div class="container">
			<?php the_content(); ?>
		</div>
	</article>
</section>
